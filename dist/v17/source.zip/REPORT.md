# Repairing a query that joins one table too many

**DASE7506 Mini-project 3 · Li Shanghang · Student ID 3036705979**

V17 obtained **194/240 on the public test (80.83%)** and **102/120 on validation (85.00%)** in both a paired comparison and an independent end-to-end run with fresh CPU model outputs and the official three-instance scorer. V15 obtained 193 and 102, respectively. Three final test answers changed. One changed from wrong to correct and all 193 previously correct answers were preserved. These are self-reported results on the released benchmark.

## Controller and costs

![V17 controller, public check gates and final action](figures/architecture.svg)

The V15 controller checks the draft, consults schema information and available repair hints, uses a local Qwen model to propose actions, and ranks candidate SQL using training-derived features. On each turn the controller receives the task and its public example, the history of tool actions and observations, and the remaining budget. The retrieval tool can supply examples from the course training bank. Each new task starts with an empty history. A query must return the required result on three database instances to earn one point. The controller may inspect the public instance through the course tools.

After V15 proposes its final SQL, the selected V17 stage examines join keys, table references and the entity the question asks to count. It has three possible edits:

* If joining other records might inflate a count, count distinct primary keys of the entity named in the question.
* For a left join, count the matched child key when the question asks how many child records exist. An unmatched parent contributes zero child keys but one joined row.
* Remove a leaf table joined by a declared foreign key when the rest of the SQL uses none of its fields and the question does not mention its distinguishing table-name terms. This can restore records dropped by an unnecessary inner join.

The terminal check determines which edits are permitted. A publicly matching incumbent can be challenged only by a family that passed the training screen; only entity counting qualified. Its replacement must also match a real public check. All three families are eligible when the exact incumbent failed publicly and no candidate passed. In that situation the controller checks proposals while it has budget, then can use its free final action for a fresh SQL. It preserves any previously unchecked V15 final answer. V17 adds no model calls. [Repair implementation](v17_cardinality.py) · [Selection protocol](evidence/protocol.md)

## What earned the additional point

A public test question asked for the distinct identifiers and names of battles that lost a ship of type `Brig`. The incumbent correctly joined battles to ships but also joined to a deaths table. That last join silently restricted the query to ships with a matching death record. Neither the requested output nor the ship-type predicate used that table. V17 removed the extra join, kept the ship-type condition, and passed all three instances. The incumbent had already failed its public check and all eight charged actions had been used. The two other modified test answers concerned counts; their pass/fail verdicts stayed the same.

## Controlled comparisons

The training comparison starts all methods from the same saved upstream trajectory on 98 tasks from 24 held-out training databases. Validation runs execute the whole controller on all 120 tasks. The paired evaluator reuses a CPU generation only after matching the model, adapter, structured and rendered prompt, token count, decoding parameters and attempt number. The official tools execute each action and a separate scorer independently replays it. The V15 control reproduced its original outputs. A dash indicates an arm evaluated during development.

| Incremental repair | Natural training holdout | Validation | Validation SQL changes | Public test |
| --- | ---: | ---: | ---: | ---: |
| V15 control | 95/98 | 102/120 | 0 | 193/240 |
| Semantic predicate edits | 94/98 | 102/120 | 0 | — |
| Relation, exclusion and intersection rewrites | 95/98 | 102/120 | 0 | — |
| Combine previously observed query results | 95/98 | 102/120 | 0 | — |
| Try those candidates earlier in the episode | 95/98 | 102/120 | 0 | — |
| Fixed composition of the four terminal stages | 94/98 | 102/120 | 2 | — |
| **Join cardinality** | **95/98** | **102/120** | **2** | **194/240** |

Validation accuracy tied. Join cardinality preserved the natural holdout score and changed two actual answers, winning the previously specified tie-break. On validation it used 565 charged tools, one more than V15. On test it used 1,121, two more than V15. The per-task maximum was eight. [Frozen comparison](evidence/selection.json)

## Training data and failure analysis

The new controller used public course training data. Generator design and screening used 382 fit questions. Earlier training stages of the inherited adapter used the full 480-question training split; the database holdout measures the incremental rule. Synthetic cases were formed by inserting a declared join into training SQL. In the 38 held-out cases for unnecessary leaves, the corrupted queries solved 4 and the repair solved 27. All of the 23 gains used training-split cases. In naturally occurring fit episodes, allowing join removal even after a public match instead lost two correct answers (355 to 353). This is the reason for the stricter trigger. In a separate held-out entity-counting control, 10/14 increased to 11/14. Across the 98 natural held-out tasks the selected policy stayed at 95/98.

The predicate arm provides a counterexample to simple keyword matching. On a held-out training question asking to exclude items above a price threshold, it detected “above” but lost the surrounding negation. The public example still matched the wrong comparison. A generated SQL, a successful public check and a correct three-instance answer are therefore measured separately. The other 46 test tasks remain incorrect under V17. The single gain does not establish transfer to a new benchmark.

## Fresh CPU reproduction and follow-up experiments

Each split ran separately on four pinned logical CPUs, loading the local base and adapter once and generating every model response from scratch. Every final SQL, tool trace and per-instance verdict matched the paired run. All 871 fresh completions matched the paired prompts, decoded outputs, token counts, settings and model identities. Each task used at most eight charged tools and four model completions. The peak memory figures below are sampled across the predictor process tree. The machine ran the two splits on disjoint CPU sets.

| Split | Correct | Tools | Completions | Prediction wall | Prediction CPU | Peak RSS | Scoring wall |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Validation | 102/120 | 565 | 275 | 26.3 min | 6,169.6 s | 3.68 GiB | 2.9 s |
| Test | 194/240 | 1,121 | 596 | 56.4 min | 13,234.3 s | 4.72 GiB | 6.7 s |

The subsequent frozen challengers tested two additional ideas. V18 asked the same model for a replacement when the incumbent explicitly failed. Its public test score tied V17 on every question while adding 27 generations and 14 charged tools. V19 tried to include tied extrema and scored 193/240. V20 combined the three mechanisms, used more model generations than V17 and also scored 194/240. V17 earns the recommendation on fresh official reproduction and lower inference cost. These public test results measure the released benchmark, which earlier project versions have also used. V18 model ablation · V19 order ablation · V20 combination · [Resource and scoring evidence](evidence/results.json)

![Validation and public test counts for the baseline and frozen challengers](figures/results.svg)

## Model and provenance

Inference uses local safetensors for `Qwen/Qwen3-0.6B` revision `c1899de289a04d12100db370d81485cdf75e47ca` and the unmerged V7 LoRA adapter. The base has 596,049,920 parameters and the adapter has 10,092,544 (606,142,464 total). The inherited model uses CPU float32 greedy decoding, thinking disabled, at most four completions per task and 384 new tokens per completion. V17 did not retrain it. The adapter SHA-256 is `2af3b904143eaffbf4a76267357c30f474a9c7408b38c76bc5f9ee8d63394aab`. The source export contains the inherited training configurations and provenance. [Inherited model and training](evidence/v15_results.json)

Questions, schema labels, tool responses and retrieved strings enter prompts as data. Restricting requests to official tool actions prevents text in these fields from directly executing commands. SQL passes through the official read-only SQLite executor, and the scorer verifies the causal trace. The deployed controller cannot access grading instances or reference fingerprints. Codex assisted with design, implementation, experiments, analysis and report preparation. Earlier development used an example project for candidate-pool and staged-ranking ideas. The V17 stages use course training and validation for development and a frozen program for public test measurement.

## Reproduction

Set the three paths and install the dependencies in the [source export instructions](README.md). From this directory run the following commands, using a separate output directory for each run.

```bash
python reproduce.py --starter "$COURSE_STARTER" --split test --output-dir ./fresh-test
python reproduce.py --starter "$COURSE_STARTER" --split validation --output-dir ./fresh-validation
python reproduce.py --starter "$COURSE_STARTER" --split test --score-only --output-dir ./rescored-test
```

