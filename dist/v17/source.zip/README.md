# V17 SQL repair agent

Li Shanghang · Student ID 3036705979 · HKU DASE7506 Mini-project 3

This agent scored **194/240 (80.83%) on the public test** and **102/120 (85.00%) on validation**. The official scorer replays each tool trace and checks all three database instances per task. The scores are local self-evaluations. [English report (PDF)](report.pdf) · [Markdown report](REPORT.md) · [Official test score](outputs/test-score.json) · [Complete test predictions](outputs/test.json)

## Install and reproduce

Unpack the course starter, this source export, and the V7 LoRA adapter into separate directories. Start in the root of this source export, on Linux with Python 3.12 and GNU time installed.

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install torch==2.7.1+cpu --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
python -m pip check
```

Set the directories to the local starter, extracted adapter and target base-model cache. Provision the pinned public base model once while online. The runner uses four logical CPUs, local weights, a single model worker, generation logging and the course resource limits. Give each invocation a new output directory.

```bash
export COURSE_STARTER=/absolute/path/to/released-starter
export MP3_ADAPTER_DIR=/absolute/path/to/extracted-adapter
export MP3_BASE_MODEL=/absolute/path/to/Qwen3-0.6B
python -c 'import os; from huggingface_hub import snapshot_download; snapshot_download("Qwen/Qwen3-0.6B", revision="c1899de289a04d12100db370d81485cdf75e47ca", local_dir=os.environ["MP3_BASE_MODEL"])'
python reproduce.py --starter "$COURSE_STARTER" --split test --output-dir ./fresh-test
python reproduce.py --starter "$COURSE_STARTER" --split validation --output-dir ./fresh-validation
```

To independently score the submitted predictions with the course scorer, run this command. Model files are unnecessary for scoring previously generated trajectories.

```bash
python reproduce.py --starter "$COURSE_STARTER" --split test --score-only --output-dir ./rescored-test
```

## Implementation and evidence

The V15 controller proposes an initial answer. V17 uses the question, schema and recorded public checks to review how joins affect which rows survive and how many rows are counted. It can remove an unused foreign-key join, count distinct entity keys or count the matched key in a left join. Removing one unnecessary join earned the extra test point over V15. The published V7 LoRA on Qwen3-0.6B is reused. The local base and unmerged adapter contain 606,142,464 parameters. The adapter weight SHA-256 is `2af3b904143eaffbf4a76267357c30f474a9c7408b38c76bc5f9ee8d63394aab`. [Runtime configuration](configs/selected.json) · [Count-repair configuration](configs/v17_cardinality.json)

Both complete official score files and prediction files are under `outputs/`. The `audit/` directory contains fresh generation transcripts, CPU times, peak memory and tool counts. Model-directory names in audit transcripts are replaced with the corresponding environment variable; the prompt and generated-text content are preserved. [Validation score](outputs/validation-score.json) · [Validation resources](audit/validation/resources_and_totals.json) · [Test resources](audit/test/resources_and_totals.json)

The `training_records/` directory includes data provenance, training configurations, loss records and the frozen V17 controller's training evidence. The `evidence/` directory records design selection, the controlled pairs and the baseline. [Protocol](evidence/protocol.md) · [Train holdout](evidence/train_holdout.json) · [V17 fit evidence](training_records/v17_cardinality.json) · [Frozen selection](evidence/selection.json)

Detailed results for the follow-up controllers appear in [V18](evidence/v18_results.json), [V19](evidence/v19_results.json), [V20](evidence/v20_results.json).
